DIDI BIRTHDAY WEBSITE

Upload index.html and the three memory photos to the ROOT of your GitHub Pages repository.

Files:
- index.html
- memory-1.jpg
- memory-2.jpg
- memory-3.jpg

For the final song:
1. Obtain an MP3 file you are allowed to use.
2. Rename it exactly: bergema-sampai-selamanya.mp3
3. Upload it to the same root folder as index.html.

The song player is already in the final section. The MP3 is not included.
Password: 2111
